/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic;

/**
 *
 * @author web-bhumi
 */
public class Loops {
    static int test ()
{
    System.out.print("Dummy");
    return 0;
}
    public static void main(String[] args) {
//        for,while,do while,for each
int i=0;
//        for(;i<5;i++)
//        System.out.println(i);
//        System.out.println("i is "+i);
//        
//  

do

System.out.println(i++ +test());

while(i<5);
   }

   
}
